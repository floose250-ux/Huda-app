
import 'package:flutter/material.dart';

void main() {
  runApp(const HudaApp());
}

class HudaApp extends StatelessWidget {
  const HudaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'هدى | Huda',
      theme: ThemeData.dark(),
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('هدى | Huda'),
      ),
      body: ListView(
        children: [
          ListTile(
            title: const Text('📖 القرآن الكريم | Quran'),
            onTap: () {},
          ),
          ListTile(
            title: const Text('📚 التفسير | Tafsir'),
            onTap: () {},
          ),
          ListTile(
            title: const Text('🕌 الأحاديث | Hadith'),
            onTap: () {},
          ),
        ],
      ),
    );
  }
}
