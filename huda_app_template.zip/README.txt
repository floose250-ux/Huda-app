
Huda Islamic App Template

Features planned:
- Quran
- Tafsir
- Hadith
- Arabic + English
- Professional design

How to build:
1. Install Flutter
2. Run: flutter pub get
3. Run: flutter build apk
